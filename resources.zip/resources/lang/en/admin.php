<?php
return [
    'Users' => __('Users')
];