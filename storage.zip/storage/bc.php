<?php
define('BC_INIT_THEME','GoTrip');
