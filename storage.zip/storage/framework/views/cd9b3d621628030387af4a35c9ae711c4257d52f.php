<div class="sidebar-widget">
    <div class="sidebar-title">
        <h2><?php echo e($item->title); ?></h2>
    </div>
    <div class="textwidget">
        <?php echo e($item->content); ?>

    </div>
</div><?php /**PATH /home/gotripne/domains/gotrip.net.ng/public_html/themes/GoTrip/News/Views/frontend/layouts/sidebars/content_text.blade.php ENDPATH**/ ?>