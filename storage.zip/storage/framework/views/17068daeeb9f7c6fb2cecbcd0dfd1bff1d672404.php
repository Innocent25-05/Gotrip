<?php switch($style):
    case ('style_2'): ?> <?php echo $__env->make('Tour::frontend.blocks.testimonial.style_2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php break; ?>
    <?php case ('style_3'): ?> <?php echo $__env->make('Tour::frontend.blocks.testimonial.style_3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php break; ?>
    <?php case ('style_4'): ?> <?php echo $__env->make('Tour::frontend.blocks.testimonial.style_4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php break; ?>
    <?php case ('style_5'): ?> <?php echo $__env->make('Tour::frontend.blocks.testimonial.style_5', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php break; ?>
    <?php case ('style_6'): ?> <?php echo $__env->make('Tour::frontend.blocks.testimonial.style_6', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php break; ?>
    <?php case ('style_7'): ?> <?php echo $__env->make('Tour::frontend.blocks.testimonial.style_7', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php break; ?>
    <?php case ('style_8'): ?> <?php echo $__env->make('Tour::frontend.blocks.testimonial.style_8', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php break; ?>
    <?php default: ?> <?php echo $__env->make('Tour::frontend.blocks.testimonial.style_1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endswitch; ?>
<?php /**PATH C:\xampp\htdocs\trip\themes/GoTrip/Tour/Views/frontend/blocks/testimonial/index.blade.php ENDPATH**/ ?>