<?php switch($layout):
    case ('style_2'): ?> <?php echo $__env->make('Location::frontend.blocks.list-locations.style_2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php break; ?>
    <?php case ('style_3'): ?> <?php echo $__env->make('Location::frontend.blocks.list-locations.style_3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php break; ?>
    <?php case ('style_4'): ?> <?php echo $__env->make('Location::frontend.blocks.list-locations.style_4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php break; ?>
    <?php case ('style_5'): ?> <?php echo $__env->make('Location::frontend.blocks.list-locations.style_5', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php break; ?>
    <?php case ('style_6'): ?> <?php echo $__env->make('Location::frontend.blocks.list-locations.style_6', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php break; ?>
    <?php case ('style_7'): ?> <?php echo $__env->make('Location::frontend.blocks.list-locations.style_7', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php break; ?>
    <?php case ('style_8'): ?> <?php echo $__env->make('Location::frontend.blocks.list-locations.style_8', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php break; ?>
    <?php case ('style_9'): ?> <?php echo $__env->make('Location::frontend.blocks.list-locations.style_9', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php break; ?>
    <?php case ('style_10'): ?> <?php echo $__env->make('Location::frontend.blocks.list-locations.style_10', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php break; ?>
    <?php default: ?> <?php echo $__env->make('Location::frontend.blocks.list-locations.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endswitch; ?>
<?php /**PATH C:\xampp\htdocs\trip\themes/GoTrip/Location/Views/frontend/blocks/list-locations/index.blade.php ENDPATH**/ ?>