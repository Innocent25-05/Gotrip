<div class="container">
    <div class="bravo-text {{$class ?? ''}}">
        {!! clean($content ?? '') !!}
    </div>
</div>