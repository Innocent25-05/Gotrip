<div class="list-star">
    <div class="d-flex relative">
        <ul class="booking-item-rating-stars d-flex x-gap-5">
            <li><i class="fa text-yellow-1 fa-star-o"></i></li>
            <li><i class="fa text-yellow-1 fa-star-o"></i></li>
            <li><i class="fa text-yellow-1 fa-star-o"></i></li>
            <li><i class="fa text-yellow-1 fa-star-o"></i></li>
            <li><i class="fa text-yellow-1 fa-star-o"></i></li>
        </ul>
        <div class="booking-item-rating-stars-active" style="width: {{  $score_total * 2 * 10 ?? 0  }}%">
            <ul class="booking-item-rating-stars d-flex x-gap-5">
                <li><i class="fa text-yellow-1 fa-star"></i></li>
                <li><i class="fa text-yellow-1 fa-star"></i></li>
                <li><i class="fa text-yellow-1 fa-star"></i></li>
                <li><i class="fa text-yellow-1 fa-star"></i></li>
                <li><i class="fa text-yellow-1 fa-star"></i></li>
            </ul>
        </div>
    </div>
</div>
