<?php
return [
    'layouts'=>[
        'normal'=>__("List Layout"),
        'grid'=>__("Grid Layout"),
        'map'=>__("Map Layout"),
    ]
];
