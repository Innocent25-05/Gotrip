<div class="sidebar-widget">
    <div class="sidebar-title">
        <h2>{{ $item->title }}</h2>
    </div>
    <div class="textwidget">
        {{ $item->content }}
    </div>
</div>