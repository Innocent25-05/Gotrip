<div class="form-group">
    <label >{{__('Term Icon')}}</label>
    <input type="text" name="icon" class="form-control" value="{{ $row->icon ?? '' }}">
</div>
